
import React, { useState } from 'react';
import Layout from './components/Layout';
import LandingPage from './components/LandingPage';
import Wizard from './components/Wizard';
import Dashboard from './components/Dashboard';
import EveAssistant from './components/EveAssistant';
import { SiteData } from './types';
import { INITIAL_SITE_DATA } from './constants';

const App: React.FC = () => {
  const [siteData, setSiteData] = useState<SiteData>(INITIAL_SITE_DATA);
  const [userEmail, setUserEmail] = useState<string | undefined>();
  const [isAuth, setIsAuth] = useState(false);
  const [showWizard, setShowWizard] = useState(false);

  const handleStartBuilding = () => {
    setUserEmail('user@helloeve.ai');
    setIsAuth(true);
    setShowWizard(true);
  };

  const handleLaunch = (data: SiteData) => {
    setSiteData({ ...data, isLaunched: true });
    setShowWizard(false);
  };

  return (
    <Layout userEmail={userEmail}>
      {!isAuth ? (
        <LandingPage onStart={handleStartBuilding} />
      ) : (
        <>
          {showWizard ? (
            <Wizard initialData={siteData} onComplete={handleLaunch} />
          ) : (
            <Dashboard siteData={siteData} />
          )}
          <EveAssistant siteData={siteData} />
        </>
      )}
    </Layout>
  );
};

export default App;
